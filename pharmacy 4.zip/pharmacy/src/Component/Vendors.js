import React from "react";
import Navbar3 from "./Navbar3";
import Table from 'react-bootstrap/Table';
function Vendors() {
    return (
        <div>
            <Navbar3/>
      <Table striped bordered hover>
        <thead>
          <tr>
            <th>First_name</th>
            <th>Last_name</th>
            <th>Email</th>
            <th>License</th>
           
            <th>Phno</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Jahnavi</td>
            <td>Boyini</td>
            <td>bowinijahnavi@gmail.com</td>
            <td>1</td>
            <td>6309241567</td>
          </tr>
         
          <tr>
            <td>Ratnmala</td>
            <td>Orusu</td>
            <td>ratnamala@gmail.com</td>
            <td>2</td>
            <td>6334521567</td>
          </tr>
         
          <tr>
          <td>Yashwanth</td>
            <td>Medi</td>
            <td>yashwanth@gmail.com</td>
            <td>3</td>
            <td>67345890253</td>
          </tr>
          <tr>
          <td>Rosik</td>
            <td>Medi</td>
            <td>yashwanth@gmail.com</td>
            <td>4</td>
            <td>67345890253</td>
          </tr>
          <td>Supriya</td>
            <td>Kodekanti</td>
            <td>supriya@gmail.com</td>
            <td>5</td>
            <td>8976902463</td>
            <tr>
            <td>Parth</td>
            <td>Dath</td>
            <td>parth@gmail.com</td>
            <td>6</td>
            <td>7976902463</td>
            </tr>
        </tbody>
      </Table>
      </div>
    );
  }
 
  export default Vendors;